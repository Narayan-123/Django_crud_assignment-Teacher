import email
from pyexpat import model
from unittest.util import _MAX_LENGTH
from django import db
from django.db import models

# Create your models here.

class Teacher(models.Model):
    name=models.CharField(max_length=25)
    email=models.EmailField(max_length=50)
    no=models.IntegerField()
    contact=models.IntegerField()

    class Meta:
        db_table='Teacher'
