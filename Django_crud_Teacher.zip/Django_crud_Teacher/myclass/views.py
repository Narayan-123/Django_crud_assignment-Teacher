from django.shortcuts import render,redirect
from myclass.models import Teacher
from .forms import Teacherform

# Create your views here.

def index(request):
    return render(request,'index.html')

def upload1(request):
   # form=Customerform() 
    if(request.method=='POST'):
        z=Teacherform(request.POST)
        if z.is_valid():
            z.save()
            return redirect('/show')
    else:
        z=Teacherform()
        return render(request,'index.html',{'hi':z})

def show(request):
    a=Teacher.objects.all()
    return render(request,'upload.html',{'hello':a})

def update(request,id):
    b=Teacher.objects.get(id=id)
    if request.method=='POST':
        form=Teacherform(request.POST,instance=b)
        if form.is_valid():
            form.save()
            return redirect("/upload")
    else:
        form=Teacherform(instance=b)
        return render(request,"index.html",{'hi':form})

def delete(request,id):
    x=Teacher.objects.get(id=id)
    x.delete()
    return redirect("/")



 